echo "foo embarassment" 
