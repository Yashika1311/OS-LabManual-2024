#include <stdio.h>

int main() {
    FILE *file;
    char filename[] = "example.txt";
    char buffer[11]; // To accommodate 10 characters plus null terminator

    // Open the file in read mode
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    // Read the first 10 bytes
    size_t bytesRead = fread(buffer, sizeof(char), 10, file);
    if (bytesRead < 10 && ferror(file)) {
        perror("Error reading file");
        fclose(file);
        return 1;
    }

    // Null-terminate the buffer to print it as a string
    buffer[bytesRead] = '\0';

    // Print the first 10 bytes
    printf("First 10 bytes of %s: %s\n", filename, buffer);

    // Close the file
    fclose(file);

    return 0;
}
